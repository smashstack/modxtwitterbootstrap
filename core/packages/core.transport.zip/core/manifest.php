<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '9a8d66f8518b2ee09d54fce93c925f65',
      'native_key' => 'core',
      'filename' => 'modNamespace/8c3a35f51d00cfe87f5466a4d20d0e79.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modWorkspace',
      'guid' => '7391cd9a909faf0821706fc412a81d6e',
      'native_key' => 1,
      'filename' => 'modWorkspace/6e5a25db64bc7be6054ab6847eb183f1.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modTransportProvider',
      'guid' => 'fbb5480b1808ada6a1882583d61d120b',
      'native_key' => 1,
      'filename' => 'modTransportProvider/10b456ef485112c69099ae31e30328fd.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'c6c494d618879abfb16dcbdd1b72d778',
      'native_key' => 'topnav',
      'filename' => 'modMenu/9b46a53b99f63102f11016097f6f3e5c.vehicle',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '8c26ba043e73683822d87d5cba764137',
      'native_key' => 'usernav',
      'filename' => 'modMenu/1dee5d21fff1017045dcf466387371e7.vehicle',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '7689cc911ac4770d61c0e6018a593473',
      'native_key' => 1,
      'filename' => 'modContentType/e2e8e64fa84c9b96da7e5f33068a8007.vehicle',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '8b3c6cfbfce10264a7e601713e6a08b9',
      'native_key' => 2,
      'filename' => 'modContentType/c29feadf63d916a196fffe4321086d6b.vehicle',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '8a7d8ed11adc2e87a568206f6a054e3d',
      'native_key' => 3,
      'filename' => 'modContentType/024709356e35e84709f41dd1000207f3.vehicle',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '475a919b604a00e9e187fab89b6402b6',
      'native_key' => 4,
      'filename' => 'modContentType/0cd7414021ba7a32fb88fee67619fb3d.vehicle',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '1eb2af87df6bf9fb79407e03f39c4875',
      'native_key' => 5,
      'filename' => 'modContentType/0a90ac6f9c21d7b492ad4ab96455c098.vehicle',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'f766d90a4c660e2892a62e69a1098afb',
      'native_key' => 6,
      'filename' => 'modContentType/e781afb36ba229986fb6908df9b8541b.vehicle',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '4460590588de1510367bd7b2aacb1a68',
      'native_key' => 7,
      'filename' => 'modContentType/7ffa884efb2dbefa7b97945017b187c4.vehicle',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '18bf1d7592c927356048bd96f93731b5',
      'native_key' => 8,
      'filename' => 'modContentType/74588845483a4c99940ba8afa1112adb.vehicle',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '2e566ae02d644eab5b9930c656952979',
      'native_key' => NULL,
      'filename' => 'modClassMap/d6ba5bc3d90a064a3f062748df45b4f8.vehicle',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'e600b1d3cff1045a495be93dbb5064b8',
      'native_key' => NULL,
      'filename' => 'modClassMap/f5f29fb92c56d1d10a07e3696ea2edd4.vehicle',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'c82964cf39a0e89676fdea502c57d7da',
      'native_key' => NULL,
      'filename' => 'modClassMap/f8e1a8dd819f235cbb00d3f98c3e17b4.vehicle',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'c240195558d4b05e6be6f6fb4f99a187',
      'native_key' => NULL,
      'filename' => 'modClassMap/08fbfb9187fa0be9b90bd398ad27cafd.vehicle',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '1ae8d54633d88cb5db62933dd0f5f6f6',
      'native_key' => NULL,
      'filename' => 'modClassMap/7bfeff623059056a45d32856eb3158a6.vehicle',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'e3085d9fff4e5e6524fc5a6ec81be0b3',
      'native_key' => NULL,
      'filename' => 'modClassMap/506e502f0b2ad0f5d44974dab8c8750e.vehicle',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'c2c6acb5d306ba83ff030cbc431814b3',
      'native_key' => NULL,
      'filename' => 'modClassMap/3e489f151bce5c9f3f742ad31a05a483.vehicle',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'dc3a5c1ae8c643e171157753ae0b7627',
      'native_key' => NULL,
      'filename' => 'modClassMap/285972afa7ca1b6ed93ef4ba9449361d.vehicle',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '1d6dd6f122c1edb5ba2f9dac8e04bc71',
      'native_key' => NULL,
      'filename' => 'modClassMap/acd28cf040d55beb3d135c923fa25cb6.vehicle',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2387e1984690456864e6487059e4f96d',
      'native_key' => 'OnPluginEventBeforeSave',
      'filename' => 'modEvent/69c901952325a2ab8a6d9f35678f17e7.vehicle',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5de82214091d20076816a5e94dc75fe2',
      'native_key' => 'OnPluginEventSave',
      'filename' => 'modEvent/8c8ab23db68c03b29e520240e4f2a0b1.vehicle',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd06731865b7f3e724f99b6eb41187836',
      'native_key' => 'OnPluginEventBeforeRemove',
      'filename' => 'modEvent/9b173a26d0934f3c3a39386ecd4cb97a.vehicle',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9c6f3b4488236aba1549a3ab9c037de0',
      'native_key' => 'OnPluginEventRemove',
      'filename' => 'modEvent/9c1dc3dfc6b436a9ee4bf786386b3bd0.vehicle',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b29df5e96457b97d50a96caab9a84180',
      'native_key' => 'OnResourceGroupSave',
      'filename' => 'modEvent/3d41caa184cea447dc118fd054d9d3a8.vehicle',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b021b9ff340b5eb9d45ea48b366b1dd4',
      'native_key' => 'OnResourceGroupBeforeSave',
      'filename' => 'modEvent/59b73781a0d7333f1d734c62c0376666.vehicle',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ab088cc154a798cef3fe9654041179ad',
      'native_key' => 'OnResourceGroupRemove',
      'filename' => 'modEvent/fdaae324d4172aa9f7d7cf0473636d6a.vehicle',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '83f0098317313cb0c67e49fd6e84ce2c',
      'native_key' => 'OnResourceGroupBeforeRemove',
      'filename' => 'modEvent/1ed53035b1a8662fe88724f88842ae0a.vehicle',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '13ba27882e9d985dc0b8dc2769a96397',
      'native_key' => 'OnSnippetBeforeSave',
      'filename' => 'modEvent/ab72893bb1b67b34858f304186a4809e.vehicle',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '900d8c3ce4c56480abf9d9ea39fa5c78',
      'native_key' => 'OnSnippetSave',
      'filename' => 'modEvent/ea297e8d7630bca382720dda5d688f3c.vehicle',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8af8f2d70a5b7767114f321962a04f9f',
      'native_key' => 'OnSnippetBeforeRemove',
      'filename' => 'modEvent/5f86268ccab9514e9f613e05ca843947.vehicle',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5038238f76aaadceaec5dd2face2e7eb',
      'native_key' => 'OnSnippetRemove',
      'filename' => 'modEvent/b83a515f273e07944487fd5622fe08ed.vehicle',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7c0e6806135bd0189f4db8b71a9b0d33',
      'native_key' => 'OnSnipFormPrerender',
      'filename' => 'modEvent/d6afd6ba3af117be7102dc0b7b1616f5.vehicle',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4b49ec30a24cf352881ac6282644ce1e',
      'native_key' => 'OnSnipFormRender',
      'filename' => 'modEvent/b70ff53309ca494dcdc5d1efbae317b7.vehicle',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '78321b6991cc3b3fde6bd1d37856af6f',
      'native_key' => 'OnBeforeSnipFormSave',
      'filename' => 'modEvent/e3d69ee54a0caeb0365c603a3f585c91.vehicle',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '77b074eaf01f3c29af8e00e0d9ad819a',
      'native_key' => 'OnSnipFormSave',
      'filename' => 'modEvent/d51708a5b8cc3ae1fafe7432ae91d3c6.vehicle',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '65c7b616e9453519f598cb0de99a6edb',
      'native_key' => 'OnBeforeSnipFormDelete',
      'filename' => 'modEvent/e84db5101e4cf33d3460ca64283065e5.vehicle',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c48fe1080bd21cbb01818f1bbd473860',
      'native_key' => 'OnSnipFormDelete',
      'filename' => 'modEvent/f95cab1c4f0226fee1550b5dd84cf87b.vehicle',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd0ca3e614a40547549cd66b038e69e6b',
      'native_key' => 'OnTemplateBeforeSave',
      'filename' => 'modEvent/14f06f3aa0d5bd85f63c02d5d0ceadfc.vehicle',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '977775a5ac243470b16b7f69be53d82c',
      'native_key' => 'OnTemplateSave',
      'filename' => 'modEvent/08bce4281a239a4cdbd9bb8b23dbd07b.vehicle',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '64185b50b7271fd5cd3008118753c786',
      'native_key' => 'OnTemplateBeforeRemove',
      'filename' => 'modEvent/18c79850e602811e80eb2c38277df22b.vehicle',
    ),
    43 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7fb1cd4ad81afb6cf22f268631d04f8e',
      'native_key' => 'OnTemplateRemove',
      'filename' => 'modEvent/ed75c36f6966fce05fcb6472d4b3bb27.vehicle',
    ),
    44 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5cea8fb46dbc97248732855368ee93c8',
      'native_key' => 'OnTempFormPrerender',
      'filename' => 'modEvent/7db7f3c1fccc00b8f7ed75d00b02e6f1.vehicle',
    ),
    45 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '16404a4340a1440e8ad3738bb3e059fe',
      'native_key' => 'OnTempFormRender',
      'filename' => 'modEvent/e9c331615517657a3e13241c701f1db0.vehicle',
    ),
    46 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1ad4fee2b571b22762089e7f8231e9f1',
      'native_key' => 'OnBeforeTempFormSave',
      'filename' => 'modEvent/79b4c90c8b957a27a07e3db4c6c06818.vehicle',
    ),
    47 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a70015570599fb34379c65732f86c75f',
      'native_key' => 'OnTempFormSave',
      'filename' => 'modEvent/451032511cb2ecd943251e9bbcf9aebc.vehicle',
    ),
    48 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '393fd3f3741baeb84b6e81bd68633125',
      'native_key' => 'OnBeforeTempFormDelete',
      'filename' => 'modEvent/d5f6bb3695870e0c67955ba830b75078.vehicle',
    ),
    49 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '85708bdc917e108c0c6ef21e7b580290',
      'native_key' => 'OnTempFormDelete',
      'filename' => 'modEvent/cefc1718001e906368ab2f30c4baf21f.vehicle',
    ),
    50 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd448d2cdcd3337c24266412457f55bd1',
      'native_key' => 'OnTemplateVarBeforeSave',
      'filename' => 'modEvent/02d71e47a76a110652ff3db981f4fdca.vehicle',
    ),
    51 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '30b5c9abbdf977e90f8db72f0003bdb0',
      'native_key' => 'OnTemplateVarSave',
      'filename' => 'modEvent/5a0a4fa0e33c152ef8f7e28ca26fb4d6.vehicle',
    ),
    52 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '55a467e3de469dce1c495d9e0efacce7',
      'native_key' => 'OnTemplateVarBeforeRemove',
      'filename' => 'modEvent/d061f6cbd550ffcc3206c141d499a1d2.vehicle',
    ),
    53 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd3cf1e401dd6a8e7020ddf1eac12ec2f',
      'native_key' => 'OnTemplateVarRemove',
      'filename' => 'modEvent/d3a4f83fb859c8747f5c6ed6bf428ae1.vehicle',
    ),
    54 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4881c7ff0b68d770f07412f88716174e',
      'native_key' => 'OnTVFormPrerender',
      'filename' => 'modEvent/4d884e155ede6aed63373eccf8796fd2.vehicle',
    ),
    55 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ee374336fcb8c8fe6245091bdc06b6bf',
      'native_key' => 'OnTVFormRender',
      'filename' => 'modEvent/1c159b50e8d694c4966d76e6699a7a28.vehicle',
    ),
    56 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bd38b5c1a739573dc73cba09e433d391',
      'native_key' => 'OnBeforeTVFormSave',
      'filename' => 'modEvent/9882912f5e1f2fc76ab7861ca332433f.vehicle',
    ),
    57 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd263930974b7339aeabc5c9d27ad89e9',
      'native_key' => 'OnTVFormSave',
      'filename' => 'modEvent/7ac6ca2efdddd11117069b5ac031db28.vehicle',
    ),
    58 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6866b6aec1a8d53e929ccc3062de0650',
      'native_key' => 'OnBeforeTVFormDelete',
      'filename' => 'modEvent/59caa6f117dd8719f89f1d8c0c85d306.vehicle',
    ),
    59 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b4148309716b9c4726141b52d6905794',
      'native_key' => 'OnTVFormDelete',
      'filename' => 'modEvent/1c8c3405985c7019a4b2b6a2e2ad1686.vehicle',
    ),
    60 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4f2694e6ba7e103dc7239601344f1310',
      'native_key' => 'OnTVInputRenderList',
      'filename' => 'modEvent/193f53f4716089db774a26257dbf079e.vehicle',
    ),
    61 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1c64d89d665a52ebc3d704dd164bcd77',
      'native_key' => 'OnTVInputPropertiesList',
      'filename' => 'modEvent/eeff19f913e9d135e5ed797ee3dd34c2.vehicle',
    ),
    62 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '761b7cc8aee7600ddfa65742c7c8ca63',
      'native_key' => 'OnTVOutputRenderList',
      'filename' => 'modEvent/b1978d5bca2c25127a71445151836a71.vehicle',
    ),
    63 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '52209e8a2456c0686120bfcc00c13d29',
      'native_key' => 'OnTVOutputRenderPropertiesList',
      'filename' => 'modEvent/2dd49b96285b7997f70b012bd89c1664.vehicle',
    ),
    64 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8246f1e91602d64114e1d5e8313b3a65',
      'native_key' => 'OnUserGroupBeforeSave',
      'filename' => 'modEvent/aa6714dd9b9508183fce019f89db56f6.vehicle',
    ),
    65 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5adcb9e08be012ef4362c6720b232df2',
      'native_key' => 'OnUserGroupSave',
      'filename' => 'modEvent/c00d563e113007aee2f0da6ed9e65551.vehicle',
    ),
    66 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '018844ac9aaa5c37e1590379b4dcf84a',
      'native_key' => 'OnUserGroupBeforeRemove',
      'filename' => 'modEvent/6cf68a10f3b1118afae4acf2fd052b66.vehicle',
    ),
    67 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2968c26cb6bd8e7831205d08504aa3df',
      'native_key' => 'OnUserGroupRemove',
      'filename' => 'modEvent/b21df6e299c0e6f8ef28b1b3a2c11e4f.vehicle',
    ),
    68 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8216f0dc2e88dffd23cf7c7f9d545bf4',
      'native_key' => 'OnBeforeUserGroupFormSave',
      'filename' => 'modEvent/99fd900a63e3e8141abaef1bfc182b14.vehicle',
    ),
    69 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0725210aa58845d8d33fe8ad013f142b',
      'native_key' => 'OnUserGroupFormSave',
      'filename' => 'modEvent/6a2979e7e85122f88734107d5c538d1f.vehicle',
    ),
    70 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8517bf9a1cd4d5f6e69913ba1a989aad',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/eb3eb3c9e4efbfa9e129d4177ba9c5a3.vehicle',
    ),
    71 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '374470bcf5f6be571a04bbabb21288f4',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/67e7743cc6316c3c64b16b21cac8be22.vehicle',
    ),
    72 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '91fa1fbfd7ef3bf04e56bdbc487ca278',
      'native_key' => 'OnDocFormPrerender',
      'filename' => 'modEvent/97592532fa32cd72fed4eedbd947f5b1.vehicle',
    ),
    73 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b152c6736ee6d08f47ae549673e146bd',
      'native_key' => 'OnDocFormRender',
      'filename' => 'modEvent/5efb985c18428631ace35abf2ae0400e.vehicle',
    ),
    74 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'caaaa0f75f5ed6353c9099d2cfcef242',
      'native_key' => 'OnBeforeDocFormSave',
      'filename' => 'modEvent/5178d59f23b17e125659f674cf64e92b.vehicle',
    ),
    75 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '21571bca23bf639556e9ee75b2135aef',
      'native_key' => 'OnDocFormSave',
      'filename' => 'modEvent/410ce40f42ef3ce6c7b900f25d1701a8.vehicle',
    ),
    76 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '458c9aad5370db0858b8be898194af73',
      'native_key' => 'OnBeforeDocFormDelete',
      'filename' => 'modEvent/4f9415f16d64de08ae03ac21b4e17d54.vehicle',
    ),
    77 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8cd1921dd2027f2f5c8c8a882504e99d',
      'native_key' => 'OnDocFormDelete',
      'filename' => 'modEvent/d7e7789be79e8a7137c0bba1b75a2dd2.vehicle',
    ),
    78 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a530613b1108d117ac22595eec82b521',
      'native_key' => 'OnDocPublished',
      'filename' => 'modEvent/9d39a1269b96199505f2522432afb244.vehicle',
    ),
    79 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8209bc454a4ce76f6bec1804e3f7fdab',
      'native_key' => 'OnDocUnPublished',
      'filename' => 'modEvent/c4e44dc340f942dde0eb664903b35755.vehicle',
    ),
    80 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9a76d389765839442f57944474d5ef48',
      'native_key' => 'OnBeforeEmptyTrash',
      'filename' => 'modEvent/9a92734fe72fa87c2e44dd925120e646.vehicle',
    ),
    81 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9e08d240e5f66783c71fd31a0e3fa1b7',
      'native_key' => 'OnEmptyTrash',
      'filename' => 'modEvent/023fa04c6f3b4de3186339b6a241c4f9.vehicle',
    ),
    82 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd7057748bf96472cd307e113c82d68e3',
      'native_key' => 'OnResourceTVFormPrerender',
      'filename' => 'modEvent/32ef69eceb88763dc3db86124baf08fb.vehicle',
    ),
    83 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'faf9727741c410988e383d3d08fbbe0d',
      'native_key' => 'OnResourceTVFormRender',
      'filename' => 'modEvent/4d04ca93ff63d81e5b46437a2f1500aa.vehicle',
    ),
    84 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7568bc48bae7b8823ac425aa55528e60',
      'native_key' => 'OnResourceAutoPublish',
      'filename' => 'modEvent/0e6116c3e5e3392adc4e299489f112ef.vehicle',
    ),
    85 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '15356f715a814096f8c833fb2c31d03f',
      'native_key' => 'OnResourceDelete',
      'filename' => 'modEvent/e5cbe24d953fd8b035c5e07a1d76eab0.vehicle',
    ),
    86 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e7fe424debfd16ae63524b072d44f5b5',
      'native_key' => 'OnResourceUndelete',
      'filename' => 'modEvent/c23f7c90213f54bee1c9edc6f57f6157.vehicle',
    ),
    87 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a4e2629161254b7f861dd9e1913906a7',
      'native_key' => 'OnResourceBeforeSort',
      'filename' => 'modEvent/a0be8d6e4e4822a1dcd55c1f93dbf529.vehicle',
    ),
    88 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e2697a56fb993fbd48dd4e7dffa82036',
      'native_key' => 'OnResourceSort',
      'filename' => 'modEvent/368912d8c888cc06807fc55cbe328cfc.vehicle',
    ),
    89 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0abae22efb24543ddec8b76aeb11327e',
      'native_key' => 'OnResourceDuplicate',
      'filename' => 'modEvent/1051ee9d83c6fd01ad7a511199f493bc.vehicle',
    ),
    90 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cce306689bb20001173145020e89587e',
      'native_key' => 'OnResourceToolbarLoad',
      'filename' => 'modEvent/db3d19c0b4404af37e34e68c4cfe7947.vehicle',
    ),
    91 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7a1bf4b48e963cc558c8962b0b42f5e1',
      'native_key' => 'OnResourceRemoveFromResourceGroup',
      'filename' => 'modEvent/1e1da821620ccd3fdec28a47a3389159.vehicle',
    ),
    92 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '40c6ed147b9e2a8e3a23ff11b468376e',
      'native_key' => 'OnResourceAddToResourceGroup',
      'filename' => 'modEvent/df8ecae8c7cce93520dea3c3aaeafedc.vehicle',
    ),
    93 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a4877de1a72ad7b8268f9fd747fb8258',
      'native_key' => 'OnRichTextEditorRegister',
      'filename' => 'modEvent/d016ddc708ed9036b50e998104b5a4b7.vehicle',
    ),
    94 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '73df651b7f4893daaf30f83198bb25a9',
      'native_key' => 'OnRichTextEditorInit',
      'filename' => 'modEvent/a3ddfea3049c466b179d4e4d7ecc8850.vehicle',
    ),
    95 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '742343b2e690ce992546163eaa8bed84',
      'native_key' => 'OnRichTextBrowserInit',
      'filename' => 'modEvent/2b75a0d793e3c1ec6b1e8c76e0c056b3.vehicle',
    ),
    96 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ad31332a3fbbbbeb1f80450f241f2b5f',
      'native_key' => 'OnWebLogin',
      'filename' => 'modEvent/6a7b049a41422d5a7af912c888b413c3.vehicle',
    ),
    97 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '99ed76586dffcbb2830a1cd70d8f1dd3',
      'native_key' => 'OnBeforeWebLogout',
      'filename' => 'modEvent/c82a4f7c0bb39f957beb845b5cc56150.vehicle',
    ),
    98 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3ac40789496f309fff200b1613e10300',
      'native_key' => 'OnWebLogout',
      'filename' => 'modEvent/51223f1fda54b3da1f7366aee049ea38.vehicle',
    ),
    99 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dcd724e28e656f37805555bfb2d197d0',
      'native_key' => 'OnManagerLogin',
      'filename' => 'modEvent/144b131419a2b9704dc4ccfab27bf8cd.vehicle',
    ),
    100 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd98f9e4779537aaf8529925ac4af3fbc',
      'native_key' => 'OnBeforeManagerLogout',
      'filename' => 'modEvent/fdbcce914c0839dce0fd7836d1a804bf.vehicle',
    ),
    101 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3ee1d01dbef8bc41ab724381259dedda',
      'native_key' => 'OnManagerLogout',
      'filename' => 'modEvent/5d675880f7f822fc192d1a83d75ea4ea.vehicle',
    ),
    102 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ebda5b98529d89f9dc142939da7bb9e3',
      'native_key' => 'OnBeforeWebLogin',
      'filename' => 'modEvent/e493911c6d5d8ed33a066b3372a2932f.vehicle',
    ),
    103 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8ab9e34f9182435423e318a088031a91',
      'native_key' => 'OnWebAuthentication',
      'filename' => 'modEvent/312537442731e2faa8a04a34e809cff3.vehicle',
    ),
    104 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8ea52eca915c5ad957bc14d3e2f1364c',
      'native_key' => 'OnBeforeManagerLogin',
      'filename' => 'modEvent/eea583b87a3d4e253e3ed08e9fdcde21.vehicle',
    ),
    105 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '439acd8107998ef12a7b9b5da413a622',
      'native_key' => 'OnManagerAuthentication',
      'filename' => 'modEvent/9adfcd92f2b66b8503240f5ff0ff8aa7.vehicle',
    ),
    106 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5b928cda4f2c6edf0254847fd92baacc',
      'native_key' => 'OnManagerLoginFormRender',
      'filename' => 'modEvent/73d9e6f713f5d525665aa8a53ae3624e.vehicle',
    ),
    107 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '36d0aed8d2a67b0673f2990010d63bfe',
      'native_key' => 'OnManagerLoginFormPrerender',
      'filename' => 'modEvent/8767891db805e8a3b393b0e09ce852e7.vehicle',
    ),
    108 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e6b291b32d825ed029f25fa89456464c',
      'native_key' => 'OnPageUnauthorized',
      'filename' => 'modEvent/f7b496df925113a0e7733ac9bdb12f14.vehicle',
    ),
    109 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dd2a119da0b0fb2a4bc931ad12be0d75',
      'native_key' => 'OnUserFormPrerender',
      'filename' => 'modEvent/f9079a82606f72635cd527231bc9c5e7.vehicle',
    ),
    110 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a481dcc9aeabc61017cf99fa99411ea6',
      'native_key' => 'OnUserFormRender',
      'filename' => 'modEvent/49bd7a52def41797e74d92f52bbb46b0.vehicle',
    ),
    111 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '57d814d7a318d110167f955179a7de73',
      'native_key' => 'OnBeforeUserFormSave',
      'filename' => 'modEvent/bc1c7fac9d73cbcf2e074772e3257fe2.vehicle',
    ),
    112 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '234a36e11a9f6727f89a919962195513',
      'native_key' => 'OnUserFormSave',
      'filename' => 'modEvent/022be7c87cd13389398d5b8d531056af.vehicle',
    ),
    113 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6a9cce115ddd8cef9534063ab6a8e6e6',
      'native_key' => 'OnBeforeUserFormDelete',
      'filename' => 'modEvent/a34c6e6a58e903bd1e617c88485719b8.vehicle',
    ),
    114 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3b5ae11860c4e70513590b14e3e21da9',
      'native_key' => 'OnUserFormDelete',
      'filename' => 'modEvent/0d2fb0f75b37517a2a39ddb5a38c6715.vehicle',
    ),
    115 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4bd44184de5b0c36d5af860ab4a30098',
      'native_key' => 'OnUserNotFound',
      'filename' => 'modEvent/7b0d56ae72187a035da204baa2cd623f.vehicle',
    ),
    116 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f42e252fa614c4b570c23fc45db6b064',
      'native_key' => 'OnBeforeUserActivate',
      'filename' => 'modEvent/1a6ecccd0b07fde0f06bb3f51427f1f8.vehicle',
    ),
    117 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '45e14c9b1c9d8288c80d589218fb33f4',
      'native_key' => 'OnUserActivate',
      'filename' => 'modEvent/fd4d943dadab539f8a88939ef37f8095.vehicle',
    ),
    118 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '76c9d4391efc89f669316666dc08aaa3',
      'native_key' => 'OnBeforeUserDeactivate',
      'filename' => 'modEvent/8aa9f9bc5ee4bd2fc59fe26017595701.vehicle',
    ),
    119 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3b1f828a783b78b86908a3ad24e4e71f',
      'native_key' => 'OnUserDeactivate',
      'filename' => 'modEvent/8a6fe4b0a13392945dfbb3ecf3b65a1d.vehicle',
    ),
    120 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '90d12872684c04583c0ce08c1a83219f',
      'native_key' => 'OnBeforeUserDuplicate',
      'filename' => 'modEvent/2f73a5ad527618ac0f09e8bd9b005468.vehicle',
    ),
    121 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '036f9ad5af337dbe77dab721ee66cb5c',
      'native_key' => 'OnUserDuplicate',
      'filename' => 'modEvent/1ab94dbc8c6c080bf49cd7f9753611c6.vehicle',
    ),
    122 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '294185ee25c56a3a71a1c385a951570f',
      'native_key' => 'OnUserChangePassword',
      'filename' => 'modEvent/5b7f66b88a127a84a739cebe42877424.vehicle',
    ),
    123 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '39f4cd87a63ae22afb2f4418a6420116',
      'native_key' => 'OnUserBeforeRemove',
      'filename' => 'modEvent/d92c5d6828c3252e36ec4996c1f52f00.vehicle',
    ),
    124 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b1621efd7f2259f53e1416cdb2305d4e',
      'native_key' => 'OnUserBeforeSave',
      'filename' => 'modEvent/db4ae91952074b5507cfd76d107d76fd.vehicle',
    ),
    125 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f236672d7d4fa057bc4d91efc2bb3d82',
      'native_key' => 'OnUserSave',
      'filename' => 'modEvent/34aed8522e5da2eaf31245ed76f3b106.vehicle',
    ),
    126 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '804bf07e08bac41e00eeb4c5c0be1733',
      'native_key' => 'OnUserRemove',
      'filename' => 'modEvent/88bf9497cb0e889621a4b674a84d2b8a.vehicle',
    ),
    127 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '20be11271439aa74f62e519b3afe08b5',
      'native_key' => 'OnUserBeforeAddToGroup',
      'filename' => 'modEvent/03f7853fce86722d182e04136ee69309.vehicle',
    ),
    128 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd5925c1f6d5d98296d59328077a060ed',
      'native_key' => 'OnUserAddToGroup',
      'filename' => 'modEvent/f7e722bf5c95be141396fbfd391714e4.vehicle',
    ),
    129 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '57aae7a697bf8b6d15b3edd243553bce',
      'native_key' => 'OnUserBeforeRemoveFromGroup',
      'filename' => 'modEvent/89e75781ce1c3a987122e61503286b38.vehicle',
    ),
    130 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5ebcf0600b87a14985f388d99033eb0c',
      'native_key' => 'OnUserRemoveFromGroup',
      'filename' => 'modEvent/cbe07676298df37aad57e71236017cd4.vehicle',
    ),
    131 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bd863e097373013cc0ee3e29e7a57ce0',
      'native_key' => 'OnWebPagePrerender',
      'filename' => 'modEvent/bc9310f76ed149db0a9dcd04cecef76d.vehicle',
    ),
    132 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8e777f469de175d80f19525bfbb55c61',
      'native_key' => 'OnBeforeCacheUpdate',
      'filename' => 'modEvent/546a1c19905985b2fc1cefac343c2ef1.vehicle',
    ),
    133 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6674621c963bd6179d21887b957d838d',
      'native_key' => 'OnCacheUpdate',
      'filename' => 'modEvent/cdd3f73a3f3897b047474544a32bfd38.vehicle',
    ),
    134 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a0356bd38995eec857fbd481d115e54c',
      'native_key' => 'OnLoadWebPageCache',
      'filename' => 'modEvent/c0342d580e0fca6712804b6d744f46d0.vehicle',
    ),
    135 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '72cd968efaea978ea0b88986703d5aab',
      'native_key' => 'OnBeforeSaveWebPageCache',
      'filename' => 'modEvent/fdd5427e4ff48d6ff45463bc0a875ce0.vehicle',
    ),
    136 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1537b558cf519fc70e3af15a0ff8165f',
      'native_key' => 'OnSiteRefresh',
      'filename' => 'modEvent/07e360928f7c7e7b6ed752ae736fc618.vehicle',
    ),
    137 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ff0b0c4fd8b468a021e77e96af7fca37',
      'native_key' => 'OnFileManagerDirCreate',
      'filename' => 'modEvent/54eb6cc93866b591ecebdca78c055907.vehicle',
    ),
    138 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd36ac3b98f386c2c0154c031a614a75f',
      'native_key' => 'OnFileManagerDirRemove',
      'filename' => 'modEvent/f9e32e5572c1d943e906734d35776375.vehicle',
    ),
    139 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '600b8eff0d74962a7e336df7f98f3fd5',
      'native_key' => 'OnFileManagerDirRename',
      'filename' => 'modEvent/60a41201b9d782d09483d4b909110223.vehicle',
    ),
    140 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6326dc0ce307804d193a5a6e24861962',
      'native_key' => 'OnFileManagerFileRename',
      'filename' => 'modEvent/7e9944972c4b797c42e261de2d78542a.vehicle',
    ),
    141 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a999814099618f5539adfcaa21f2a71d',
      'native_key' => 'OnFileManagerFileRemove',
      'filename' => 'modEvent/57e756f5b41baa54eca0ef096337339f.vehicle',
    ),
    142 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8f1a74f1a81f528db8182afefb4375ed',
      'native_key' => 'OnFileManagerFileUpdate',
      'filename' => 'modEvent/481012ece73ecd003f9551379c0f6914.vehicle',
    ),
    143 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c4ee3ee5152fa89a1840aae570ce2027',
      'native_key' => 'OnFileManagerFileCreate',
      'filename' => 'modEvent/258dcab0455436d6d457c95adc48291a.vehicle',
    ),
    144 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ec8009f7507b96cf328a03d0b89222e0',
      'native_key' => 'OnFileManagerBeforeUpload',
      'filename' => 'modEvent/a5e473c26c780ee9012be2926ac234d1.vehicle',
    ),
    145 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3cf09a4e966a1f4bd3aa44bf20c56573',
      'native_key' => 'OnFileManagerUpload',
      'filename' => 'modEvent/8146fae213325d79675a430aa26b3177.vehicle',
    ),
    146 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '348fa8353c21228cffead8ddc8bcf7c7',
      'native_key' => 'OnFileManagerMoveObject',
      'filename' => 'modEvent/41852cebaf35a478774e70852bd0f939.vehicle',
    ),
    147 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '181186ca49578a4e3f413bc3c2d0e852',
      'native_key' => 'OnFileCreateFormPrerender',
      'filename' => 'modEvent/7207f70ac785a2e627492ff86281afb9.vehicle',
    ),
    148 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7ac818ff7a11a7396afc95471ba84867',
      'native_key' => 'OnFileEditFormPrerender',
      'filename' => 'modEvent/80a02473e370ee18e28e8de07c379d6f.vehicle',
    ),
    149 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8334f44f183c372ea1b1b6c83686830c',
      'native_key' => 'OnManagerPageInit',
      'filename' => 'modEvent/492ebd67bec925278f2ba0f4b8c49531.vehicle',
    ),
    150 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5b34c272e44b7c056c00462c2c4f05d3',
      'native_key' => 'OnManagerPageBeforeRender',
      'filename' => 'modEvent/53daae43d6ced55a7280cd63a9ccbc39.vehicle',
    ),
    151 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bd9c7a939b6649c950f28fae6cee91b1',
      'native_key' => 'OnManagerPageAfterRender',
      'filename' => 'modEvent/817d58282f031dc5ebf05c2510acdaac.vehicle',
    ),
    152 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0471718060c8957057cd00c639464f16',
      'native_key' => 'OnWebPageInit',
      'filename' => 'modEvent/f43d1b31d61597fe07e3ffc409e64e28.vehicle',
    ),
    153 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c099928ba59dc85aaa2b976c58d2cd18',
      'native_key' => 'OnLoadWebDocument',
      'filename' => 'modEvent/8e776097f7b3dd4600bdc60a40897fb7.vehicle',
    ),
    154 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3170192d163bcf9c8b16f59010c847e7',
      'native_key' => 'OnParseDocument',
      'filename' => 'modEvent/99f0e07df0e6075aa9aa706fad054bb2.vehicle',
    ),
    155 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8e8dca4705f3ce92d543abdb2d659db9',
      'native_key' => 'OnWebPageComplete',
      'filename' => 'modEvent/6f8844d5ae94eeee6b4cfd98a4f94cce.vehicle',
    ),
    156 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e5357a5cc3b2c0675a4c8276dc855b14',
      'native_key' => 'OnBeforeManagerPageInit',
      'filename' => 'modEvent/31b924e3b1c43e5ab13927d56247255a.vehicle',
    ),
    157 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c5ce5d89eef28009c1d120cccbd4a893',
      'native_key' => 'OnPageNotFound',
      'filename' => 'modEvent/4d47ee0828f5534f7490b95a46f6ca90.vehicle',
    ),
    158 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '720d33336392274d756f738e681f4649',
      'native_key' => 'OnHandleRequest',
      'filename' => 'modEvent/b9c82d98828e9c614f1f9a26510dfc8e.vehicle',
    ),
    159 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '96d9d1511280f3a99c06018543b31040',
      'native_key' => 'OnMODXInit',
      'filename' => 'modEvent/792ab403096c2ec3b749de34c4d3fbf6.vehicle',
    ),
    160 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e7b1d2f6f0368ba25d23fedc72e6e6dd',
      'native_key' => 'OnElementNotFound',
      'filename' => 'modEvent/c1ff3aa2faf1bd16dd1c23b68054a562.vehicle',
    ),
    161 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd87ae78e3ef6df3e89d160be5f92d324',
      'native_key' => 'OnSiteSettingsRender',
      'filename' => 'modEvent/9c7e8c072873a735a5b73a84ef04ed13.vehicle',
    ),
    162 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '31b4a1089dcaa0756eb292ab9b606187',
      'native_key' => 'OnInitCulture',
      'filename' => 'modEvent/d2ccc353f0b610b15d9c9a08d0c47120.vehicle',
    ),
    163 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '52dcf7414f25992a9d4f16dfc1c92cfe',
      'native_key' => 'OnCategorySave',
      'filename' => 'modEvent/defc62eec0f577de3852092a895c8d0c.vehicle',
    ),
    164 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd78692d00a84bc44e0efab7ac63748df',
      'native_key' => 'OnCategoryBeforeSave',
      'filename' => 'modEvent/65c37fe8206091a0a7de9e609f4c1abe.vehicle',
    ),
    165 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9ff968fe25dca5a42d64e3c82eb363da',
      'native_key' => 'OnCategoryRemove',
      'filename' => 'modEvent/4d83ddff2a6e767bac0be95da452c612.vehicle',
    ),
    166 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b02df1bccb447b8f478b7ef5e8a38208',
      'native_key' => 'OnCategoryBeforeRemove',
      'filename' => 'modEvent/7f6837b70fb5770ab613ee1e9fad0a95.vehicle',
    ),
    167 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a0d1231def75f9adc45b72f6733eb1da',
      'native_key' => 'OnChunkSave',
      'filename' => 'modEvent/c686a2ae1105c6e33c2e1908e764fee3.vehicle',
    ),
    168 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2f4f7c5b4461b90e2b6510e897b4f4af',
      'native_key' => 'OnChunkBeforeSave',
      'filename' => 'modEvent/e7a402d1b08cbdd44738338fbc666668.vehicle',
    ),
    169 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1d87abb785f1a0146c2078adfa7c96d2',
      'native_key' => 'OnChunkRemove',
      'filename' => 'modEvent/4b4ac0e437905d91551940b46e4b0e1a.vehicle',
    ),
    170 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a0010c8aeed40bea4bb5f9ca76f29516',
      'native_key' => 'OnChunkBeforeRemove',
      'filename' => 'modEvent/cbca759f23a634bf1ed83638101c4342.vehicle',
    ),
    171 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dfcd48b86a88e5060fadadd6ea671dbc',
      'native_key' => 'OnChunkFormPrerender',
      'filename' => 'modEvent/f79d27f6241d3d7303e7abc6d78ebe72.vehicle',
    ),
    172 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '446ffc261c53526e4a3f7580ed4f34b7',
      'native_key' => 'OnChunkFormRender',
      'filename' => 'modEvent/a620272eeecd522735a215c709b424ac.vehicle',
    ),
    173 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2cee737432016fc715de3ad31cf34bdf',
      'native_key' => 'OnBeforeChunkFormSave',
      'filename' => 'modEvent/4b3a49918d1a7657875ab6b9d0847ecd.vehicle',
    ),
    174 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bcd126c999e0554a9547bcbb546d7ea9',
      'native_key' => 'OnChunkFormSave',
      'filename' => 'modEvent/a0c7e42e720054de8cae520fc2863cd4.vehicle',
    ),
    175 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '07b0e8935256769823726ac09a3cf111',
      'native_key' => 'OnBeforeChunkFormDelete',
      'filename' => 'modEvent/cd3a3c2b6997c7901f00a88568660eef.vehicle',
    ),
    176 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6bac3f42a152939fded7def5562211b8',
      'native_key' => 'OnChunkFormDelete',
      'filename' => 'modEvent/50468881e9d28b253f46dd8b4e181895.vehicle',
    ),
    177 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f8a72cd4e62e1b0d2c7974e285c1cf6c',
      'native_key' => 'OnContextSave',
      'filename' => 'modEvent/6487a12144ab60f39cb0656be100b945.vehicle',
    ),
    178 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '238f4c312fc6a160262c537cd6eaa1b1',
      'native_key' => 'OnContextBeforeSave',
      'filename' => 'modEvent/5582765f08b89fe583b6d4785d26ec2b.vehicle',
    ),
    179 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'afbcca9624267bc5b53f233f24d5e75b',
      'native_key' => 'OnContextRemove',
      'filename' => 'modEvent/e4cad4291150aebe4d2de4a86fae2b56.vehicle',
    ),
    180 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '73de77a2451543137e9a1326c9e1592b',
      'native_key' => 'OnContextBeforeRemove',
      'filename' => 'modEvent/522a4a9830d71df70c176c432b99243a.vehicle',
    ),
    181 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '35a07ff212416743ed7d7845f6f152da',
      'native_key' => 'OnContextFormPrerender',
      'filename' => 'modEvent/2d189589b1c14d7afaef88a782e7d620.vehicle',
    ),
    182 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fcff3521de4b9f5d07d7919e86bd13d9',
      'native_key' => 'OnContextFormRender',
      'filename' => 'modEvent/435523306eaae8181cd3159e058257b8.vehicle',
    ),
    183 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd532c6728a13c9f2afc1fd673048e7d7',
      'native_key' => 'OnPluginSave',
      'filename' => 'modEvent/9af10bd7e1481b558eac1bebd805ab3a.vehicle',
    ),
    184 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a66f87020e52d8e57cc33e83f32fcdf3',
      'native_key' => 'OnPluginBeforeSave',
      'filename' => 'modEvent/4798e077473fb146c1ca0f4b422bb218.vehicle',
    ),
    185 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '53a040dc69653c59e660319b0a450c90',
      'native_key' => 'OnPluginRemove',
      'filename' => 'modEvent/a09a310d75d64c8211558cc633387bdb.vehicle',
    ),
    186 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bd11f99c0797a3524b3a48eae929ccb9',
      'native_key' => 'OnPluginBeforeRemove',
      'filename' => 'modEvent/def6f88ce3a3bf3cefeb64f2fef2ab11.vehicle',
    ),
    187 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a7bff908e9eb703d2ce147ead8ec0cec',
      'native_key' => 'OnPluginFormPrerender',
      'filename' => 'modEvent/4ce60aa1117f99b07666c54defa7438e.vehicle',
    ),
    188 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '195c8c08e8f7c0d1eb9c7fd0cad010d5',
      'native_key' => 'OnPluginFormRender',
      'filename' => 'modEvent/40b9b2a56718176c056e28e3fce2add5.vehicle',
    ),
    189 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c34202c392eeb01f539da74e9dbfe528',
      'native_key' => 'OnBeforePluginFormSave',
      'filename' => 'modEvent/5d5d9415149de3158987cdb78076f961.vehicle',
    ),
    190 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fe9e7d60c62141c84bebe3c8e18d0bf7',
      'native_key' => 'OnPluginFormSave',
      'filename' => 'modEvent/cd08a5d1fb663a4ebc7dc1704b981216.vehicle',
    ),
    191 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7f5dee0195fd85580c207279aa3c8b6f',
      'native_key' => 'OnBeforePluginFormDelete',
      'filename' => 'modEvent/77b6f2dc233a6b81e6e7727f19d2c3d6.vehicle',
    ),
    192 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '20463d7665a6d0ecc4325ee205d22dfe',
      'native_key' => 'OnPluginFormDelete',
      'filename' => 'modEvent/97ea2d804b8f405cac2d563d6f786b5c.vehicle',
    ),
    193 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bef3b8a450e6efbcfc1be1184ed4df28',
      'native_key' => 'OnPropertySetSave',
      'filename' => 'modEvent/2017113c9c8bf3ebc4dac017b4edc46b.vehicle',
    ),
    194 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1a143606a32cffb4d2ad607dbfc3848f',
      'native_key' => 'OnPropertySetBeforeSave',
      'filename' => 'modEvent/79fc75e36a58163ff403aad878b9782e.vehicle',
    ),
    195 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1b87aabea80c4153cb690c6d60c1da53',
      'native_key' => 'OnPropertySetRemove',
      'filename' => 'modEvent/7334b5aa0126600312a2defacb05b2ec.vehicle',
    ),
    196 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '549231e68a308b240a0c5f29b5ee726a',
      'native_key' => 'OnPropertySetBeforeRemove',
      'filename' => 'modEvent/11ecab0ac8c3a850df29b6df52d45700.vehicle',
    ),
    197 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f64200d3b371f9291de586b7af7eab17',
      'native_key' => 'OnMediaSourceBeforeFormDelete',
      'filename' => 'modEvent/3dfabd5ad73d974c5d6aae76e30d1830.vehicle',
    ),
    198 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a5e05bbdd1c0d05496e56f617a4b488d',
      'native_key' => 'OnMediaSourceBeforeFormSave',
      'filename' => 'modEvent/ef665f406d8f4dae517ddee7c2dea88c.vehicle',
    ),
    199 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ebca8c41522a59ca85ec53941478d953',
      'native_key' => 'OnMediaSourceGetProperties',
      'filename' => 'modEvent/52580f25e86273eead8979030c102a88.vehicle',
    ),
    200 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'efabce01e8ba3e3eca951323d32c24ba',
      'native_key' => 'OnMediaSourceFormDelete',
      'filename' => 'modEvent/7fc550287a8e8291822dfa66cce8c240.vehicle',
    ),
    201 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8528e80f81e9033a1fab2981df7c8a3a',
      'native_key' => 'OnMediaSourceFormSave',
      'filename' => 'modEvent/6236665f5d25d44163262a3c3650bf76.vehicle',
    ),
    202 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '38a0f2f7c4bea0b61b5a9ab04b422c17',
      'native_key' => 'OnMediaSourceDuplicate',
      'filename' => 'modEvent/9923cc6cc7f0a524fe2834eb85874ce9.vehicle',
    ),
    203 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e44aa5f77a4ebdcf3523bcef3f7ee757',
      'native_key' => 'access_category_enabled',
      'filename' => 'modSystemSetting/3fcfa4da625bf3e70ae663dd87eb58c4.vehicle',
    ),
    204 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '88470c44395b738362ba022c9fabf7e5',
      'native_key' => 'access_context_enabled',
      'filename' => 'modSystemSetting/d6d33e70e73d3945384897acc9f88733.vehicle',
    ),
    205 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '616d83f18c2c1ef26d2f812e335ab66e',
      'native_key' => 'access_resource_group_enabled',
      'filename' => 'modSystemSetting/af5553e83f1519743da74160383e6656.vehicle',
    ),
    206 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd01fea8927c9460e3eea79fd67717c5e',
      'native_key' => 'allow_forward_across_contexts',
      'filename' => 'modSystemSetting/1a839b02fcc0094b7dba60478068ea13.vehicle',
    ),
    207 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dd9e2f1b6483369aaff6a2e83c20aa19',
      'native_key' => 'allow_manager_login_forgot_password',
      'filename' => 'modSystemSetting/a91296b1a411c342780929ba4874388f.vehicle',
    ),
    208 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0977540c60347a29bc8f23725a1508ad',
      'native_key' => 'allow_multiple_emails',
      'filename' => 'modSystemSetting/a2a492b06a63dc1100a71d471cb19f69.vehicle',
    ),
    209 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dc86f521c1b8b8a142c51f3e5836b6ba',
      'native_key' => 'allow_tags_in_post',
      'filename' => 'modSystemSetting/f95a37ebdff0dbf551f4207fdcd9a160.vehicle',
    ),
    210 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6167d3e1c09811d2cc5416690a620dad',
      'native_key' => 'archive_with',
      'filename' => 'modSystemSetting/53e130aaa3e0533b8c9388ccc86554b0.vehicle',
    ),
    211 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '47420bdd740fa74d701c59bde2536f24',
      'native_key' => 'auto_menuindex',
      'filename' => 'modSystemSetting/5bddc83e325ed411ce7b402ce7481466.vehicle',
    ),
    212 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3b799efc09e3f7c93962f793841809d6',
      'native_key' => 'auto_check_pkg_updates',
      'filename' => 'modSystemSetting/e7ee207cd3769c58999d5cde99dff3d6.vehicle',
    ),
    213 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5c1f58503c4daf0e1a8f436816fbb313',
      'native_key' => 'auto_check_pkg_updates_cache_expire',
      'filename' => 'modSystemSetting/e0d5a67d7175d1e47feca267bd4fe17b.vehicle',
    ),
    214 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '14b6b682fb19b9b3bdbeeee4cb6f2ae6',
      'native_key' => 'automatic_alias',
      'filename' => 'modSystemSetting/e69b3931d3a6271d5622d8cc91fddc8d.vehicle',
    ),
    215 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'de3aaa40d27952f3bda08735f8fdcc13',
      'native_key' => 'base_help_url',
      'filename' => 'modSystemSetting/4ba5abae8bb5dd33ac959a2bd7e984d0.vehicle',
    ),
    216 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5b573b67f702c8c01e06bdee90d6c0c0',
      'native_key' => 'blocked_minutes',
      'filename' => 'modSystemSetting/a4568bf158cea0bfcfbe034144c25b03.vehicle',
    ),
    217 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '390e262cd7d2c8e98bd76a73656b1ad9',
      'native_key' => 'cache_action_map',
      'filename' => 'modSystemSetting/4f95582e6ae1861b6796743dde32d399.vehicle',
    ),
    218 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '98f874bd65fbeb18694267689f0974b6',
      'native_key' => 'cache_alias_map',
      'filename' => 'modSystemSetting/bca311dc5c8020c9222e96d02154d3b6.vehicle',
    ),
    219 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd5d5caca0341a8b19ef8dff53a0beed7',
      'native_key' => 'cache_context_settings',
      'filename' => 'modSystemSetting/35cc5a2ba9f9bdacc93f859d1b0905c5.vehicle',
    ),
    220 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cd41d91a8e3cfdf6602e809a6d6fff4a',
      'native_key' => 'cache_db',
      'filename' => 'modSystemSetting/4b68cdff41fafe5c55a9b7dccba85a44.vehicle',
    ),
    221 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0b0f153a268137e691500f74555d6684',
      'native_key' => 'cache_db_expires',
      'filename' => 'modSystemSetting/0025cb066f2b5d23dfdd1e0609e51e98.vehicle',
    ),
    222 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4ea847173e3cda4d9cd1941092d37c5f',
      'native_key' => 'cache_db_session',
      'filename' => 'modSystemSetting/8f6bc6e0cca80238cabd6ab869ae9717.vehicle',
    ),
    223 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a5be431ebf93569d3f207de9dcc688d4',
      'native_key' => 'cache_db_session_lifetime',
      'filename' => 'modSystemSetting/9c7a032d3ba5152c9ea4a41f97a716cc.vehicle',
    ),
    224 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5a254c473b5f24256679e27986dd5514',
      'native_key' => 'cache_default',
      'filename' => 'modSystemSetting/c71a05e0fa2ea3e3c320507a09b7c557.vehicle',
    ),
    225 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6ad2ecd618b1609a87f51c85d5ee377e',
      'native_key' => 'cache_disabled',
      'filename' => 'modSystemSetting/a91ea8b0e9bf398f763e4a52d78f1be3.vehicle',
    ),
    226 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '979bcfefd3eade443f55aaa81aa01786',
      'native_key' => 'cache_expires',
      'filename' => 'modSystemSetting/7405639e8e14b887cd9329ae2a3efe4d.vehicle',
    ),
    227 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ec0d77d79037ebd7cca383dbc7be7db1',
      'native_key' => 'cache_format',
      'filename' => 'modSystemSetting/983c3378ccff4aff1d990cb2f9242771.vehicle',
    ),
    228 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '10fc9bb0d24bdcd3d59065306f2d5a66',
      'native_key' => 'cache_handler',
      'filename' => 'modSystemSetting/8226af8cbc6ee449a67cd9dbac40b474.vehicle',
    ),
    229 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'df486af8779cb2841db1442bd9ff53ca',
      'native_key' => 'cache_lang_js',
      'filename' => 'modSystemSetting/89c362d66f57edf5839d2b486308fce2.vehicle',
    ),
    230 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f1c525f070df116d61bf164b97acf128',
      'native_key' => 'cache_lexicon_topics',
      'filename' => 'modSystemSetting/e765f28dcc694698f04400f561f7c945.vehicle',
    ),
    231 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd92fc5fc111a162c7892b550644b2627',
      'native_key' => 'cache_noncore_lexicon_topics',
      'filename' => 'modSystemSetting/d929d2120f3e9f8a6770a4306c3ccca0.vehicle',
    ),
    232 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9b8c45aa24b100fb0767f160d6a1a622',
      'native_key' => 'cache_resource',
      'filename' => 'modSystemSetting/9e7aaf6812b657d626c1d0ac570b9e1e.vehicle',
    ),
    233 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '268765712a5750a57d8da96064ea06ca',
      'native_key' => 'cache_resource_expires',
      'filename' => 'modSystemSetting/3cbed4e1d7d49b74b2e18b573aa7bfa4.vehicle',
    ),
    234 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e393aaa294ea45744de432682f5cb9fb',
      'native_key' => 'cache_scripts',
      'filename' => 'modSystemSetting/ab3af81f5ddd5d3db3a722e7995e4cc7.vehicle',
    ),
    235 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c1ed0495883f5a82faa8c3705b078bca',
      'native_key' => 'cache_system_settings',
      'filename' => 'modSystemSetting/b2c0840abdce47233e2c0227d6b8a5a4.vehicle',
    ),
    236 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '930d3fb2649cbcb07be928ff68a1a5dd',
      'native_key' => 'clear_cache_refresh_trees',
      'filename' => 'modSystemSetting/31da0f2cdf0b1806d079bac0adb0e75f.vehicle',
    ),
    237 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b77b3443de6ed16f1d8a98133247a3e4',
      'native_key' => 'compress_css',
      'filename' => 'modSystemSetting/d20071a49a799fc77a5858a8af05490a.vehicle',
    ),
    238 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0cd1e41910a859b06d989ac420b6a5ae',
      'native_key' => 'compress_js',
      'filename' => 'modSystemSetting/baa3658b1c56564cefb1af9cc3a187fc.vehicle',
    ),
    239 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1f9282a054f69a34ee8e058ddba817d8',
      'native_key' => 'compress_js_max_files',
      'filename' => 'modSystemSetting/b40453f32b868f31a87d22974556fd61.vehicle',
    ),
    240 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e138b52224b63e713f281c10378e551e',
      'native_key' => 'compress_js_groups',
      'filename' => 'modSystemSetting/8dd00d174015dbf639b4e96d2687f723.vehicle',
    ),
    241 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8aaf8c42b652b01171b4b263cccfa862',
      'native_key' => 'confirm_navigation',
      'filename' => 'modSystemSetting/f8aeb083c6611f3a1c0313c657c75e89.vehicle',
    ),
    242 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4407a976f4120e4330d9a553c84c5a3e',
      'native_key' => 'container_suffix',
      'filename' => 'modSystemSetting/ad63b2d81638f7bc27401f6e2c96fe21.vehicle',
    ),
    243 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '23b2f9689e811138b1a22b5fece1ebe1',
      'native_key' => 'context_tree_sort',
      'filename' => 'modSystemSetting/ba3b7f9ef335cbc9cea4d2656edf38b7.vehicle',
    ),
    244 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aef68c94e109694eac870bacc2545a3c',
      'native_key' => 'context_tree_sortby',
      'filename' => 'modSystemSetting/55eea8d05693d436d4c342c51f002ace.vehicle',
    ),
    245 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2eefd9393a4b060991deed4618a30d67',
      'native_key' => 'context_tree_sortdir',
      'filename' => 'modSystemSetting/40d5c44aa5b209dd7b3c9b402daf22db.vehicle',
    ),
    246 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'de91ed2bc35b149f6ade4d5e827e66e3',
      'native_key' => 'cultureKey',
      'filename' => 'modSystemSetting/c93d0598366cf7b70a5feb4554c22a31.vehicle',
    ),
    247 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0f3dda40af2b494254347a144d08c004',
      'native_key' => 'date_timezone',
      'filename' => 'modSystemSetting/dfff9a9c815026a00b51373de5e4c971.vehicle',
    ),
    248 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9df1fdfc8d849972c47154f389ba90e9',
      'native_key' => 'debug',
      'filename' => 'modSystemSetting/facf8f22153e8f3a4e70a174e7eac6ee.vehicle',
    ),
    249 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd5d4adf1a7ae482be558b8e97e2d5d6f',
      'native_key' => 'default_duplicate_publish_option',
      'filename' => 'modSystemSetting/e54c6862d9b9113213757d0eeb20698c.vehicle',
    ),
    250 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f8b4b2b46709b24781c3b9db5418ee7f',
      'native_key' => 'default_media_source',
      'filename' => 'modSystemSetting/22b616cb8f2ad92b27fbf22bde2760b5.vehicle',
    ),
    251 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7b55c054940bbe865c912cbe4146fec0',
      'native_key' => 'default_per_page',
      'filename' => 'modSystemSetting/836d23d0b7231e4adfbdebe97801893a.vehicle',
    ),
    252 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '367d0600564ec6e138decb03fa035c7d',
      'native_key' => 'default_context',
      'filename' => 'modSystemSetting/e23de45de0c7d77496824ae64474982b.vehicle',
    ),
    253 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aabfc5637a21d3d98ba100931e5a4c2a',
      'native_key' => 'default_template',
      'filename' => 'modSystemSetting/72ef141f718bb1bdc5baa7fb8f97cbf7.vehicle',
    ),
    254 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7a96e272c09c08a052b6cf5252e93fb9',
      'native_key' => 'default_content_type',
      'filename' => 'modSystemSetting/7584f69c780f18bcd63f473df39d81b7.vehicle',
    ),
    255 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '77df3389fa9e0e20d0ebce98a783f125',
      'native_key' => 'editor_css_path',
      'filename' => 'modSystemSetting/4cda9714d7579b1288843de76b22ab1c.vehicle',
    ),
    256 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '088cc352471b579012ff4b129dad747b',
      'native_key' => 'editor_css_selectors',
      'filename' => 'modSystemSetting/88a24a08ae48882d14114029ab5747a8.vehicle',
    ),
    257 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4d8538b3241c6cbfcdad4baab8195d04',
      'native_key' => 'emailsender',
      'filename' => 'modSystemSetting/9497cbfecb7c2690ef691d5fd1709d02.vehicle',
    ),
    258 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f2d3c134d2c64dfb2597de4af25fcbd5',
      'native_key' => 'emailsubject',
      'filename' => 'modSystemSetting/0ca98403cb503ba437a05542cf8da3d5.vehicle',
    ),
    259 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4c1dfbebbaaf5884a6b09b37ac544cbe',
      'native_key' => 'enable_dragdrop',
      'filename' => 'modSystemSetting/128831b0261da288de2d955363f8feac.vehicle',
    ),
    260 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f119588706c4eb990f91963e80d2870d',
      'native_key' => 'error_page',
      'filename' => 'modSystemSetting/e24e54abeabce9ab317aaa635e79731b.vehicle',
    ),
    261 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '23c35f232a0bed92abee38491531f5d9',
      'native_key' => 'failed_login_attempts',
      'filename' => 'modSystemSetting/6ef12b37f0e7532e3a6fd74e950d9463.vehicle',
    ),
    262 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'db9124c7e40e79fa41daf6e98698952a',
      'native_key' => 'fe_editor_lang',
      'filename' => 'modSystemSetting/efae14c8a0c7a00c8c4aed8b66c2db1b.vehicle',
    ),
    263 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '00cd94ceef96615e5f34ff0d1ece8075',
      'native_key' => 'feed_modx_news',
      'filename' => 'modSystemSetting/7272d30e8b35e40d3b3d0940b0af110c.vehicle',
    ),
    264 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3c59bc9787ab02b7833c1dad57173bba',
      'native_key' => 'feed_modx_news_enabled',
      'filename' => 'modSystemSetting/fa49ad43e3ddb8fe61fb0107cefc11ef.vehicle',
    ),
    265 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e8d46a4c96bce82c4fead8911be2ace2',
      'native_key' => 'feed_modx_security',
      'filename' => 'modSystemSetting/50eb9f0bb1798018a9ae230c9c592469.vehicle',
    ),
    266 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4da4363b4ba8ce3bff1d389957cbc6a2',
      'native_key' => 'feed_modx_security_enabled',
      'filename' => 'modSystemSetting/b56b0978d21b82f0db40478fc3290dbc.vehicle',
    ),
    267 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3332ed9f7cfeaca67f33a26872203a83',
      'native_key' => 'filemanager_path',
      'filename' => 'modSystemSetting/25274529c1f0263aecceb84fbec26919.vehicle',
    ),
    268 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4d3636dc91cdfb9fe29e4bb10017896c',
      'native_key' => 'filemanager_path_relative',
      'filename' => 'modSystemSetting/2aebbb873322b8c206d146562ac3b8bd.vehicle',
    ),
    269 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd157eb4f91b70f4bdbb0a1604765eaa4',
      'native_key' => 'filemanager_url',
      'filename' => 'modSystemSetting/c1663b55186bee157f86d35488abf2de.vehicle',
    ),
    270 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '85f3e5338b1a818866593ed21f55147e',
      'native_key' => 'filemanager_url_relative',
      'filename' => 'modSystemSetting/7486b6079a8edb657b85854a882d21bf.vehicle',
    ),
    271 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '55d4150a894a8f9897173d5c2b768918',
      'native_key' => 'forgot_login_email',
      'filename' => 'modSystemSetting/6c918ef337998f4cc17aa0c8a1b9f3db.vehicle',
    ),
    272 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aa9f3c41c7ae24b979e911ee69eab2f2',
      'native_key' => 'form_customization_use_all_groups',
      'filename' => 'modSystemSetting/830d27705dcce702f637624f7e265b5f.vehicle',
    ),
    273 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dcd4ad799687ce9339868c99d8ec4d20',
      'native_key' => 'forward_merge_excludes',
      'filename' => 'modSystemSetting/8d1b9396646c8e017d116220a20bc67e.vehicle',
    ),
    274 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2b431b124f9c4cba240bce0d7161cf53',
      'native_key' => 'friendly_alias_lowercase_only',
      'filename' => 'modSystemSetting/455dec180ff7294daaae59af54188678.vehicle',
    ),
    275 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1998d9238ecfd7af66c4c050fa09fa8e',
      'native_key' => 'friendly_alias_max_length',
      'filename' => 'modSystemSetting/cd9119dbfab8928d7fac086e085a4bb5.vehicle',
    ),
    276 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aade9f7dae4d367b86392b982b28b4b7',
      'native_key' => 'friendly_alias_restrict_chars',
      'filename' => 'modSystemSetting/a131b62c1821f84275bfe6947eafc948.vehicle',
    ),
    277 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e7376e997c38a2145f5f51250bb51f64',
      'native_key' => 'friendly_alias_restrict_chars_pattern',
      'filename' => 'modSystemSetting/2207bf1d3bb4f84f6210cdbf9acc2e96.vehicle',
    ),
    278 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4550b5241443cd5a467f0fb5cff72852',
      'native_key' => 'friendly_alias_strip_element_tags',
      'filename' => 'modSystemSetting/1a28a17bccc06c61ee495588bcc95e0b.vehicle',
    ),
    279 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '96da98614d7f8da6e2da88cae2c5d09e',
      'native_key' => 'friendly_alias_translit',
      'filename' => 'modSystemSetting/a47eb16ab25d57e421a85df8d45d1454.vehicle',
    ),
    280 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '69d2b6a90ba0ca772e7a5d52cb22da04',
      'native_key' => 'friendly_alias_translit_class',
      'filename' => 'modSystemSetting/8bb564c5aa3ce847a8cf9b76cfb3d0f8.vehicle',
    ),
    281 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aae7762f93870be767652f6f38a216bf',
      'native_key' => 'friendly_alias_translit_class_path',
      'filename' => 'modSystemSetting/4833aeac8759909755911938aff3146d.vehicle',
    ),
    282 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cf9eb123a2201d6352d7adbaf2a55262',
      'native_key' => 'friendly_alias_trim_chars',
      'filename' => 'modSystemSetting/383fadaf54a709423b78efcfb08044c1.vehicle',
    ),
    283 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'db01d80c2750e2388a07335b97c72a0f',
      'native_key' => 'friendly_alias_word_delimiter',
      'filename' => 'modSystemSetting/4b35c0c33ce634e0534cc72dfdd826ef.vehicle',
    ),
    284 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a242a39be9587bc0d30bc481f79b633d',
      'native_key' => 'friendly_alias_word_delimiters',
      'filename' => 'modSystemSetting/5897ea02a0173d510df512f9d05b8b47.vehicle',
    ),
    285 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3a0dde1286e8fbd5094509c3bda1c4e4',
      'native_key' => 'friendly_urls',
      'filename' => 'modSystemSetting/42eebe79c045da570edaa71aff3131a6.vehicle',
    ),
    286 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2a7fac3a2b7e764bfdac9fc6cfa99c92',
      'native_key' => 'friendly_urls_strict',
      'filename' => 'modSystemSetting/25af37a1e3b08ccffa8968e91bdc0faf.vehicle',
    ),
    287 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5a6da3df12739166dff73708fb565adf',
      'native_key' => 'global_duplicate_uri_check',
      'filename' => 'modSystemSetting/5c53c9c837a0bab1635611b09df97bb9.vehicle',
    ),
    288 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1cda2b47a85b421bc23fcd86641b6d55',
      'native_key' => 'hidemenu_default',
      'filename' => 'modSystemSetting/b6719c63b347f00d9c638d862b1a6097.vehicle',
    ),
    289 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd351dd02e3c38faea4fc6ab439ee87b7',
      'native_key' => 'inline_help',
      'filename' => 'modSystemSetting/ddf9abc12abc0e40e33de07000239a1e.vehicle',
    ),
    290 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9f67217c313abcc2701c094e4ddf2abf',
      'native_key' => 'locale',
      'filename' => 'modSystemSetting/84bcc735e9f7b39a3e87aed16af1ba0c.vehicle',
    ),
    291 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '282c5a2e3e91e656a3218b3d81d4946e',
      'native_key' => 'log_level',
      'filename' => 'modSystemSetting/92643d0c957aaadc0a91606cadea78e0.vehicle',
    ),
    292 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e4b03092ebbc7932a916480b6ab26cfd',
      'native_key' => 'log_target',
      'filename' => 'modSystemSetting/46169c270daba99b8f21f56f0fb62a5f.vehicle',
    ),
    293 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dd96cea90ddd98e88d1a564a790dc92c',
      'native_key' => 'link_tag_scheme',
      'filename' => 'modSystemSetting/c3d86656a080b886312bf53e31749273.vehicle',
    ),
    294 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cb9babd3b9f80c5fe8c2366160fb9555',
      'native_key' => 'lock_ttl',
      'filename' => 'modSystemSetting/53ed1a3e985cdc369054087fd7691b3b.vehicle',
    ),
    295 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cae02f7a7738cf45f113764627d3b010',
      'native_key' => 'mail_charset',
      'filename' => 'modSystemSetting/23defb64bcc5eab66382dd8eca6c8b6e.vehicle',
    ),
    296 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8e6df6b5994691f9d081228a6c81af29',
      'native_key' => 'mail_encoding',
      'filename' => 'modSystemSetting/8ef1ece465f0c0b7a265596977f5a0b0.vehicle',
    ),
    297 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '75c5d3f0d8479549d8fb9a18af249d1e',
      'native_key' => 'mail_use_smtp',
      'filename' => 'modSystemSetting/9d66b39c0aebf6fad6aa21c66d510047.vehicle',
    ),
    298 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '63717c443b2ca1a7b67a87e3eed2494f',
      'native_key' => 'mail_smtp_auth',
      'filename' => 'modSystemSetting/d6c373be750594d8a2e42ac22b2c83d5.vehicle',
    ),
    299 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '60bd1471780fb70ea97eb58f690321aa',
      'native_key' => 'mail_smtp_helo',
      'filename' => 'modSystemSetting/691dc5e9a9b3174622d60745f70905ca.vehicle',
    ),
    300 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c5fcb4042f4b5dbb4d1580d7fecd0608',
      'native_key' => 'mail_smtp_hosts',
      'filename' => 'modSystemSetting/2a94a183b2923978c2eefd27d3d1a4a8.vehicle',
    ),
    301 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7ea9c458870118d6a173b9efdcb80152',
      'native_key' => 'mail_smtp_keepalive',
      'filename' => 'modSystemSetting/62a2271d87fc0c31f1fc7e50010715da.vehicle',
    ),
    302 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '757c9712b8eaaed8a4f0ffe94d86cb82',
      'native_key' => 'mail_smtp_pass',
      'filename' => 'modSystemSetting/7a7afee0c0f1e17a8c32d376771de9c0.vehicle',
    ),
    303 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0272a23da6f04aa4a189cb9c842e9752',
      'native_key' => 'mail_smtp_port',
      'filename' => 'modSystemSetting/c0564d141652d24829c0e24c898bacb6.vehicle',
    ),
    304 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '30175ae5a918248cf183e58ad432007b',
      'native_key' => 'mail_smtp_prefix',
      'filename' => 'modSystemSetting/1db55cf5afacb173c305cf86608ec720.vehicle',
    ),
    305 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3305eba99158ae47b4c5e30af87ebd82',
      'native_key' => 'mail_smtp_single_to',
      'filename' => 'modSystemSetting/896b6e0cf5c981786e8c7692b9ed04e3.vehicle',
    ),
    306 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b9331d8e5b39931ff12c8da12745fd19',
      'native_key' => 'mail_smtp_timeout',
      'filename' => 'modSystemSetting/95260b981396c41391baa0fe27eab631.vehicle',
    ),
    307 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6ca613b653d5101b12ae5ccb43c5af8a',
      'native_key' => 'mail_smtp_user',
      'filename' => 'modSystemSetting/5692f6f28f877164257c90ac568380a5.vehicle',
    ),
    308 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a320cc49a9fb3871c3e029fb67cd7e52',
      'native_key' => 'manager_date_format',
      'filename' => 'modSystemSetting/c5209ee65772f070e14e858fb9957792.vehicle',
    ),
    309 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fb1d53cfa560c77dad6a359c697cce66',
      'native_key' => 'manager_favicon_url',
      'filename' => 'modSystemSetting/d5d5265239876952f39a5b6e9a227296.vehicle',
    ),
    310 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '921b02f565e491d099fd91755a2a87bb',
      'native_key' => 'manager_html5_cache',
      'filename' => 'modSystemSetting/86b5acfee28d605f3b3a82141d3c42a1.vehicle',
    ),
    311 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '124a2c160101bff3d85c9f5667e66fb9',
      'native_key' => 'manager_js_cache_file_locking',
      'filename' => 'modSystemSetting/b81473c214bea80570fb46767fa54890.vehicle',
    ),
    312 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fada7c52521c0b6419f6be2cf63c50de',
      'native_key' => 'manager_js_cache_max_age',
      'filename' => 'modSystemSetting/4e898cc424b006e9f6ef65fb5f7793f2.vehicle',
    ),
    313 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f72b3ba99005494edfb204b75ea5935a',
      'native_key' => 'manager_js_document_root',
      'filename' => 'modSystemSetting/ce72f7bfa33786cd125ef811b8476dbf.vehicle',
    ),
    314 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7cb538f158fe1307219069f385ed8208',
      'native_key' => 'manager_js_zlib_output_compression',
      'filename' => 'modSystemSetting/5d0ebb02b4b5302bb65c2980e05fa770.vehicle',
    ),
    315 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f31c099c4a35038afc8edd0619b63a2d',
      'native_key' => 'manager_time_format',
      'filename' => 'modSystemSetting/f434c84c416d578bc6445002140dee9b.vehicle',
    ),
    316 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9f260abc901045c54f84a2cf6d7dec20',
      'native_key' => 'manager_direction',
      'filename' => 'modSystemSetting/4552e1795807bb1dcdf499b6118171a0.vehicle',
    ),
    317 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b90d581f0c58980dac80227334f43ead',
      'native_key' => 'manager_lang_attribute',
      'filename' => 'modSystemSetting/daecd4508e9caa719de2be86b589ff0f.vehicle',
    ),
    318 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '53aef902bbc52520bb5b62e16203d8d5',
      'native_key' => 'manager_language',
      'filename' => 'modSystemSetting/ffd27ae15b090e4dcf9b269ad40204e7.vehicle',
    ),
    319 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e3442bcc9719fdc688d9b88fa0f0fca9',
      'native_key' => 'manager_login_url_alternate',
      'filename' => 'modSystemSetting/8bb075d0676458a14eab0d94846be512.vehicle',
    ),
    320 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '30520f02a6a8e97c1b24f1eb14167225',
      'native_key' => 'manager_theme',
      'filename' => 'modSystemSetting/1ce6a2acae5b21454f055740e16deb9d.vehicle',
    ),
    321 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '342fe6b60d26d942d6d15562f2a46455',
      'native_key' => 'manager_week_start',
      'filename' => 'modSystemSetting/99e88d4403903120e5143feb9e3057fb.vehicle',
    ),
    322 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1005c2a80db9411ea8bf6a9129b708e6',
      'native_key' => 'modx_browser_default_sort',
      'filename' => 'modSystemSetting/57b3091c8295ecd72975535ee45cb983.vehicle',
    ),
    323 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'af79b016d4d866e078d47be16c754c52',
      'native_key' => 'modx_browser_default_viewmode',
      'filename' => 'modSystemSetting/a712c06338fa94e99704b9ad6fe7bb9f.vehicle',
    ),
    324 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2fe701ad7492ff64607ebc355d2e20dc',
      'native_key' => 'modx_charset',
      'filename' => 'modSystemSetting/c1e53fdcbd725a2a8122089c5d6d147a.vehicle',
    ),
    325 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '37e6b2e2a81a4240572827e953faee36',
      'native_key' => 'principal_targets',
      'filename' => 'modSystemSetting/2608db780da6d59945e78cec2a5c3425.vehicle',
    ),
    326 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a875368c8d6e7e4e2fba9488c8285db5',
      'native_key' => 'proxy_auth_type',
      'filename' => 'modSystemSetting/6c9fa6b63c3b06e02022100263075ec6.vehicle',
    ),
    327 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5ce55fbcedeaaf3b115e235b33fb338c',
      'native_key' => 'proxy_host',
      'filename' => 'modSystemSetting/b764b4ebf37b692dd313c6364ca5daaf.vehicle',
    ),
    328 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0de6d67e7d307df60fb69639f4600987',
      'native_key' => 'proxy_password',
      'filename' => 'modSystemSetting/620bd233de90901c0e0f95d8e7f3b568.vehicle',
    ),
    329 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c304091111aceeeb531960bec5d751cf',
      'native_key' => 'proxy_port',
      'filename' => 'modSystemSetting/90d75934808c1f7dc346d0cad9321936.vehicle',
    ),
    330 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4661c4f0715587084562fc4124a81600',
      'native_key' => 'proxy_username',
      'filename' => 'modSystemSetting/efefedbd416054b0db5f5d1cba49517f.vehicle',
    ),
    331 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6c6a4745ace6a71851d1ada358ac56d9',
      'native_key' => 'password_generated_length',
      'filename' => 'modSystemSetting/a78f32c72b954f7b01e4e2a4ca460e85.vehicle',
    ),
    332 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b6b7304fa8137f91879486e373742535',
      'native_key' => 'password_min_length',
      'filename' => 'modSystemSetting/d6026099e1d14eb784d19eeff32ed3db.vehicle',
    ),
    333 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cd1b309d1e41b7ab3080229d2768d8f5',
      'native_key' => 'phpthumb_allow_src_above_docroot',
      'filename' => 'modSystemSetting/a5435abfefd4c755e73adf542b4b87ac.vehicle',
    ),
    334 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ca06d1e286e9a080417d9bb851aa70be',
      'native_key' => 'phpthumb_cache_maxage',
      'filename' => 'modSystemSetting/0586233cbae80fd6cffc2a5599619460.vehicle',
    ),
    335 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e123cb52485c569ba94417925457f7e1',
      'native_key' => 'phpthumb_cache_maxsize',
      'filename' => 'modSystemSetting/149807e1233c6b5f95338c6a86c7eb1c.vehicle',
    ),
    336 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3b746e6762bc750a8c064fee411041e7',
      'native_key' => 'phpthumb_cache_maxfiles',
      'filename' => 'modSystemSetting/d91a88f00a0767175bec45e77919b0c0.vehicle',
    ),
    337 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0dd3f465120acd14d79be9194902fa7e',
      'native_key' => 'phpthumb_cache_source_enabled',
      'filename' => 'modSystemSetting/7e142d1591a84905b7ceb823ef1d56a5.vehicle',
    ),
    338 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4eb21a873ca13910b2fcb5387adbdab4',
      'native_key' => 'phpthumb_document_root',
      'filename' => 'modSystemSetting/620dfd4791da92467e92e51acabfc4af.vehicle',
    ),
    339 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ec4d28eb7d40fc59c56cf8d09e580705',
      'native_key' => 'phpthumb_error_bgcolor',
      'filename' => 'modSystemSetting/6f084e36bb53a55b8ce3154c3da229e9.vehicle',
    ),
    340 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0d0ff3fb3a8205ddb01ecff0373f704b',
      'native_key' => 'phpthumb_error_textcolor',
      'filename' => 'modSystemSetting/1da4b5409efedcbe43621ed956a19698.vehicle',
    ),
    341 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b3d429da4f1a93b9e1ca3d43088efe95',
      'native_key' => 'phpthumb_error_fontsize',
      'filename' => 'modSystemSetting/45fa3ca4449f4f0dc55df74beae8655b.vehicle',
    ),
    342 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0d7813d5b7eb9f7181ece18234890a62',
      'native_key' => 'phpthumb_far',
      'filename' => 'modSystemSetting/8a8acc6a6fb9b0f67c5382f2825b0002.vehicle',
    ),
    343 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f3c6a872effcc5d21e828ee674f71266',
      'native_key' => 'phpthumb_imagemagick_path',
      'filename' => 'modSystemSetting/4751cfee86bc608300aba45c4b452321.vehicle',
    ),
    344 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5ec68e7880f254b9c42f9c6b37f9beb9',
      'native_key' => 'phpthumb_nohotlink_enabled',
      'filename' => 'modSystemSetting/0e0ddfb0546099ad37f8c194139e9d23.vehicle',
    ),
    345 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eb9dbbb4a10f3d2f05447c7644302d2c',
      'native_key' => 'phpthumb_nohotlink_erase_image',
      'filename' => 'modSystemSetting/f08b3ac44a5a57b95a0c426b79cfc11f.vehicle',
    ),
    346 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '91ec4252b7ae3ce1e86c2eeb621f56de',
      'native_key' => 'phpthumb_nohotlink_valid_domains',
      'filename' => 'modSystemSetting/870164ab7ad16b8db7e0d0e07db01b8b.vehicle',
    ),
    347 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c8580d187b289c9e2ba60762360d270c',
      'native_key' => 'phpthumb_nohotlink_text_message',
      'filename' => 'modSystemSetting/510049809bed4869bb5290a54fec5bc5.vehicle',
    ),
    348 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '07fee86b8455b32137171531f2f98e15',
      'native_key' => 'phpthumb_nooffsitelink_enabled',
      'filename' => 'modSystemSetting/d2c510ce7502ab0b6338e562d084c185.vehicle',
    ),
    349 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dbbc8ffa290d78e472fd67cda609fce9',
      'native_key' => 'phpthumb_nooffsitelink_erase_image',
      'filename' => 'modSystemSetting/e362504a490810cf993cfc6e94b86ff4.vehicle',
    ),
    350 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b170cc885a0e59f9126d349db690a797',
      'native_key' => 'phpthumb_nooffsitelink_require_refer',
      'filename' => 'modSystemSetting/cfc6f70d61738b2ba45fd9f6b1429e21.vehicle',
    ),
    351 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a47508fb0cb54504b50daf578c0cf5f7',
      'native_key' => 'phpthumb_nooffsitelink_text_message',
      'filename' => 'modSystemSetting/4cdb145f6dcc20ab431c50989d6804da.vehicle',
    ),
    352 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c6f93ecff61561d1319a467d4fab5c2e',
      'native_key' => 'phpthumb_nooffsitelink_valid_domains',
      'filename' => 'modSystemSetting/2c52a38182c37e39db60f29e278c303f.vehicle',
    ),
    353 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '53475a6c2190e46162297e8d097f2e10',
      'native_key' => 'phpthumb_nooffsitelink_watermark_src',
      'filename' => 'modSystemSetting/27e7376437b688c67c54d334d24273b9.vehicle',
    ),
    354 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a486c67b38e494e60931af1588c22477',
      'native_key' => 'phpthumb_zoomcrop',
      'filename' => 'modSystemSetting/3555222cd9f7ef3db3ec2f51d3b7b214.vehicle',
    ),
    355 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '37e2150bdc0f4a39e231747400bd2d5d',
      'native_key' => 'publish_default',
      'filename' => 'modSystemSetting/ca90036fddd1f7458c02d07cdc41445f.vehicle',
    ),
    356 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '58be11d208bb708692987ca2416095de',
      'native_key' => 'rb_base_dir',
      'filename' => 'modSystemSetting/b54069a8983431993e83facfb3b44953.vehicle',
    ),
    357 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1f2db56f2e004252129df371d4af6843',
      'native_key' => 'rb_base_url',
      'filename' => 'modSystemSetting/d104f7b00e20beddad30cfbace111855.vehicle',
    ),
    358 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ed5e701a9c7984e62975eaa5cfb4bd01',
      'native_key' => 'request_controller',
      'filename' => 'modSystemSetting/f9396a765685ecc33fc91435f0911d2a.vehicle',
    ),
    359 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '52cd6dd94cfb1aaa7e2ac49723fda2fd',
      'native_key' => 'request_method_strict',
      'filename' => 'modSystemSetting/aedecb42b728fc04a8f7afb6d5583cef.vehicle',
    ),
    360 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e584d9c1047235268b2759d9d30c89c7',
      'native_key' => 'request_param_alias',
      'filename' => 'modSystemSetting/f92ed286085235aa4276ba23430154fb.vehicle',
    ),
    361 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ef529fa87ae5e6f22d8d718f636193dd',
      'native_key' => 'request_param_id',
      'filename' => 'modSystemSetting/0fc9462d665c667b8bd8adf11a0d1753.vehicle',
    ),
    362 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ec6faaae5d8c14151e0c9842f3b349e3',
      'native_key' => 'resolve_hostnames',
      'filename' => 'modSystemSetting/977c78e2d50e2a2da200bb9e49941d70.vehicle',
    ),
    363 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3d7e8c4a5d5d0f2462792f520e4255be',
      'native_key' => 'resource_tree_node_name',
      'filename' => 'modSystemSetting/212bd5bce5722b56283ce5da731d71e7.vehicle',
    ),
    364 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e0248f9746fcd0f843e2507a4335541d',
      'native_key' => 'resource_tree_node_name_fallback',
      'filename' => 'modSystemSetting/d1519d32afecb66d43d7d319dd2020aa.vehicle',
    ),
    365 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e55f75bb96b753899b1bc63d0875865b',
      'native_key' => 'resource_tree_node_tooltip',
      'filename' => 'modSystemSetting/33c9c2d1c76fcc0f35c5e90c1d011e4e.vehicle',
    ),
    366 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cea3686eb67e406e6eb393a853c4ea62',
      'native_key' => 'richtext_default',
      'filename' => 'modSystemSetting/34549067cb666cc34d6d657ca4b16937.vehicle',
    ),
    367 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '35c6d8a370fb9b27caceeea613c81047',
      'native_key' => 'search_default',
      'filename' => 'modSystemSetting/713c6bf428f4b5f0eed6a70dcc57ec9b.vehicle',
    ),
    368 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '126b12e409a21e2d31bfbee4dbbb8331',
      'native_key' => 'server_offset_time',
      'filename' => 'modSystemSetting/36ae880e0c9b25947780cd44437d15fb.vehicle',
    ),
    369 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a5cf9506553ce1c38c1135988109ff11',
      'native_key' => 'server_protocol',
      'filename' => 'modSystemSetting/2f7c9def9a57b2bd5b013e7a00cb6aec.vehicle',
    ),
    370 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '038cea40f3f583a7bc1506a224ed70d6',
      'native_key' => 'session_cookie_domain',
      'filename' => 'modSystemSetting/3786cf62aa91269b7bd4432c9363276a.vehicle',
    ),
    371 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3619fc7d692ab89c04a7c24ba1d075a1',
      'native_key' => 'session_cookie_lifetime',
      'filename' => 'modSystemSetting/4dfad1fc4204ecdc414919a8ad14c23f.vehicle',
    ),
    372 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e09a57c322ce3d0d462e5405eb05b62f',
      'native_key' => 'session_cookie_path',
      'filename' => 'modSystemSetting/08552ba47f5368d447e5dc369e2f3fee.vehicle',
    ),
    373 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '81d58387db46368d2b1dd1fb7a78b6a5',
      'native_key' => 'session_cookie_secure',
      'filename' => 'modSystemSetting/b3c2bd6fb8fd237b580fca61c02c9995.vehicle',
    ),
    374 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9c0e6f951b7a787504c1dc427c7ce0b7',
      'native_key' => 'session_cookie_httponly',
      'filename' => 'modSystemSetting/b103ec9a3a9558adf7f47d78647702f1.vehicle',
    ),
    375 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '226295acfca8f2e74f0b4e4f23c1acb9',
      'native_key' => 'session_gc_maxlifetime',
      'filename' => 'modSystemSetting/8b157c20cea490f263d9a1f4c0e7bc3e.vehicle',
    ),
    376 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f1f6147947bf308714c6050ecd1d6cc2',
      'native_key' => 'session_handler_class',
      'filename' => 'modSystemSetting/89a8a395bd8f0d1b3947fd5a9695ca33.vehicle',
    ),
    377 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '241c9cade5cc1a03c5ecf8418649b9b1',
      'native_key' => 'session_name',
      'filename' => 'modSystemSetting/5a7ba7fa76f89be735b9fe07f81713af.vehicle',
    ),
    378 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b3851c72280f0ce198fea0023b696212',
      'native_key' => 'set_header',
      'filename' => 'modSystemSetting/95aa3099fe44e5da87bcaf1e6699d650.vehicle',
    ),
    379 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7746e2900fc7c9c46dc395e13375a2ee',
      'native_key' => 'show_tv_categories_header',
      'filename' => 'modSystemSetting/17ae51c810a81a1d45d3fd8a2275a33f.vehicle',
    ),
    380 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9e16ab1b796875814dd23d4a5de86adb',
      'native_key' => 'signupemail_message',
      'filename' => 'modSystemSetting/ef176964a2dde50185ca2676974e5a26.vehicle',
    ),
    381 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'be002217ccca1bfebf9e62546329454f',
      'native_key' => 'site_name',
      'filename' => 'modSystemSetting/087d5ff40ad0a10494ad1b91a2930e1d.vehicle',
    ),
    382 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '852360f71d2739ce73c8bc1e1a25689a',
      'native_key' => 'site_start',
      'filename' => 'modSystemSetting/5e5298b53eaf6d167a9d9343d753b516.vehicle',
    ),
    383 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7f0e4feac26664392f666bfc7aa3bb3e',
      'native_key' => 'site_status',
      'filename' => 'modSystemSetting/b56fc19313bc3195b8e87fb072abe159.vehicle',
    ),
    384 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '750109e0fd941799abaf3187da6fdf58',
      'native_key' => 'site_unavailable_message',
      'filename' => 'modSystemSetting/e055020a6179123babc97fe4830e9f8d.vehicle',
    ),
    385 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0a4cfb8e6dc8239f87e16b3477618c18',
      'native_key' => 'site_unavailable_page',
      'filename' => 'modSystemSetting/772300fe1fc94565a33ef0201ef637b5.vehicle',
    ),
    386 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f208a79c3b3d649bb309aef07f7919d6',
      'native_key' => 'strip_image_paths',
      'filename' => 'modSystemSetting/7ef7cf355db320b1b0f6292972eb14ee.vehicle',
    ),
    387 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dd593c90a8c4c67a507103e0a0fe6139',
      'native_key' => 'symlink_merge_fields',
      'filename' => 'modSystemSetting/f004beb1886a369caa70096c1ab984b5.vehicle',
    ),
    388 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9f34b2764a5cea0ba183765c1eae3d1d',
      'native_key' => 'topmenu_show_descriptions',
      'filename' => 'modSystemSetting/ddd290b3c3455670b71b4b0ef9e30716.vehicle',
    ),
    389 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1e0d016f90788a70885ef0d41b56467c',
      'native_key' => 'tree_default_sort',
      'filename' => 'modSystemSetting/2281ac5ddaa87ab444acbd2aa6511703.vehicle',
    ),
    390 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dd8a09ddb8fd373fe58a1204aa639c48',
      'native_key' => 'tree_root_id',
      'filename' => 'modSystemSetting/b44ed20870f2d19121b92f30b862f0fd.vehicle',
    ),
    391 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '66b19f79a6ba823de5fdeebc2ae9129f',
      'native_key' => 'tvs_below_content',
      'filename' => 'modSystemSetting/20530ff7a1b5f83d32ed9dc97b17f4a9.vehicle',
    ),
    392 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fc7a28621ce81dc11add4e094b909a34',
      'native_key' => 'udperms_allowroot',
      'filename' => 'modSystemSetting/aee0ea62efb102b623565162f51d0e06.vehicle',
    ),
    393 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '524a9196e968653dc94c92cf6fdda44d',
      'native_key' => 'unauthorized_page',
      'filename' => 'modSystemSetting/be0c2f6b1ab20e7a03eafcab2f29fc1d.vehicle',
    ),
    394 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cf47d282ec12a29f15dbbe462a53ae4c',
      'native_key' => 'upload_files',
      'filename' => 'modSystemSetting/f3adbed243944cfee0eb6b56b407232f.vehicle',
    ),
    395 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '301b806b55e1902b4ee3c5df70988756',
      'native_key' => 'upload_flash',
      'filename' => 'modSystemSetting/cb4b4b7bb1c4612ee792a25c33e95516.vehicle',
    ),
    396 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '93af93102dd9e0b8d657fd1d7a3bbb20',
      'native_key' => 'upload_images',
      'filename' => 'modSystemSetting/47d3f8049de6d3a4b61179582b74d270.vehicle',
    ),
    397 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '925ed925a9971b2ffe4900313305b1c0',
      'native_key' => 'upload_maxsize',
      'filename' => 'modSystemSetting/6204de8783881f44b801d442f289bfbb.vehicle',
    ),
    398 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '24bb73b3c0d90f4539329c64833b3ad7',
      'native_key' => 'upload_media',
      'filename' => 'modSystemSetting/ea1c7b69c8c0435c7892deb4f9c1e950.vehicle',
    ),
    399 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2790fd2e289ca54a7e20e626145e60e3',
      'native_key' => 'use_alias_path',
      'filename' => 'modSystemSetting/4e3788aa830eb63392b3183fff249f10.vehicle',
    ),
    400 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c2da57b73328986e42d77b5cd51e3f2b',
      'native_key' => 'use_browser',
      'filename' => 'modSystemSetting/63a2292f344ad39fc8a7b66ae33b8efb.vehicle',
    ),
    401 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '593fe53c002c792aa1f21ebb517bb02d',
      'native_key' => 'use_editor',
      'filename' => 'modSystemSetting/f7bd9f898895260bb7e5972b9409b94b.vehicle',
    ),
    402 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2e0abba0798bfe19159dd20d66fbd414',
      'native_key' => 'use_multibyte',
      'filename' => 'modSystemSetting/ff9be1e6945827eda65d02f823b73cfd.vehicle',
    ),
    403 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5e41f44c6b54e8897e0bcf02635cce24',
      'native_key' => 'use_weblink_target',
      'filename' => 'modSystemSetting/91c5f83ff835dd126b0c82c4ca7cbf53.vehicle',
    ),
    404 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cfb39d1f8f190f59685e5fdd6710c118',
      'native_key' => 'webpwdreminder_message',
      'filename' => 'modSystemSetting/a36cace26fc55edf3e10422ff51ec3c2.vehicle',
    ),
    405 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b83471f91deb9c01c28076dcd27b626c',
      'native_key' => 'websignupemail_message',
      'filename' => 'modSystemSetting/9f4a03bd3f5a6fa1a8125b06755e73b2.vehicle',
    ),
    406 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '20d4a526eb1b554e0df648c2773c32dc',
      'native_key' => 'welcome_screen',
      'filename' => 'modSystemSetting/849746852849ef18783b627a31181429.vehicle',
    ),
    407 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a63f1d913520e81c6d918421a35ffc0f',
      'native_key' => 'welcome_screen_url',
      'filename' => 'modSystemSetting/6835695f612c92fe9bccbb024ba2399b.vehicle',
    ),
    408 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3c1b9deddaaa92578c74af7e1aad545e',
      'native_key' => 'welcome_action',
      'filename' => 'modSystemSetting/9ea808e4cd20fcfcd4e850fc276eb311.vehicle',
    ),
    409 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5f9464646977c2ab929dd05afd7e627d',
      'native_key' => 'welcome_namespace',
      'filename' => 'modSystemSetting/b77e3b1d6fe8f0f37f0266e133149fff.vehicle',
    ),
    410 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e44260a679f208fffc1c601505416174',
      'native_key' => 'which_editor',
      'filename' => 'modSystemSetting/46d3973aad70e87d5e8965f0e1ce4b17.vehicle',
    ),
    411 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0d7b2c20e15ecbabc3010f2d180af8fb',
      'native_key' => 'which_element_editor',
      'filename' => 'modSystemSetting/14b04f1b19d23b6652780d9b36f3a21f.vehicle',
    ),
    412 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cc95990caa5c8eff79f427d810f0924f',
      'native_key' => 'xhtml_urls',
      'filename' => 'modSystemSetting/037165784b0b372221f13a370a0e09b4.vehicle',
    ),
    413 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7d9efd03e64003ddeb47ee07e534e3a1',
      'native_key' => 'enable_gravatar',
      'filename' => 'modSystemSetting/2c9e784d63148e0af0f9bd9646b77231.vehicle',
    ),
    414 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '371ae54260208e6ee776f0f323e58143',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'allow_tags_in_post',
      ),
      'filename' => 'modContextSetting/86fd4d79334d5a39a8187bf8279ae88e.vehicle',
    ),
    415 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => 'a375b655b1de0511595f70a50a73d22f',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'modRequest.class',
      ),
      'filename' => 'modContextSetting/19ac374186ecae8438a0e96144d314da.vehicle',
    ),
    416 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroup',
      'guid' => '9f4bd41c2e379f04744e2437ed669542',
      'native_key' => 1,
      'filename' => 'modUserGroup/f7dc54281a13d3ed982c61667b05edf8.vehicle',
    ),
    417 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboard',
      'guid' => '7ca157402e601b5f1604cc9d3fdaee25',
      'native_key' => 1,
      'filename' => 'modDashboard/1e7a4952b5de8078ef90ef555d55a3fe.vehicle',
    ),
    418 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMediaSource',
      'guid' => '7c7a4691cb34018eedd75de1f0510181',
      'native_key' => 1,
      'filename' => 'modMediaSource/c5200e8ef493b2f02155936b7053a8a7.vehicle',
    ),
    419 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'c8b37da85fec5d61e9dd1f2a94853d68',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/fa1b9cdff2d5e13ed3776da943272e3d.vehicle',
    ),
    420 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'f372641b572affdd13fb05ad4d2f7f96',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/094d752f58f8f96f7b7037192784c9b6.vehicle',
    ),
    421 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'b1014c1a034ccf6610622ff4bfa75145',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/ea70cb0543fd77023bee02ae5ffe3d7c.vehicle',
    ),
    422 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '12005a6787112f740fe25bce0ae4a65d',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/45c2b7c98c193e0ed67ae6813bc96012.vehicle',
    ),
    423 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'f5b224f4862d86a081fc8dd824c50488',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/31a70fbc7892c15736cb0ec2c6353daf.vehicle',
    ),
    424 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => '644acee58200db3832495dc5b7f3fb07',
      'native_key' => 1,
      'filename' => 'modUserGroupRole/1f3c0aeb729a794f4162ed862c0a2067.vehicle',
    ),
    425 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => '87b0892555ed91005d634ae867ed65a3',
      'native_key' => 2,
      'filename' => 'modUserGroupRole/218309a985ff86f57d2a4b839dfd3fb8.vehicle',
    ),
    426 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '538abb1b7e7865c473edba10ceed7504',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/8ecca5ab34e23a295d530e5157192f71.vehicle',
    ),
    427 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '78dd4129649ba6a3895b2558eed1b647',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/ffb099e88c7562d469c9c9f7e05bf5ae.vehicle',
    ),
    428 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '7ce3e46164cc80b57058dc9e97a377f8',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/06efd23f8811c3c035061c7377b0c23f.vehicle',
    ),
    429 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '83fc2a930001f5a7ffe8bf9fbdf066d4',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/8f6e5d39b41ac76aa785eaf6b859e06a.vehicle',
    ),
    430 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '09fa5bbb1e6a2e336cd4d95fcb880f77',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/e479bb4781fe5e925997fb7e9f8317ea.vehicle',
    ),
    431 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '2083432d3ab050dfc1eb375a65db52ef',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/f9aeabb0bae4a964f4d0cf14065e8f3d.vehicle',
    ),
    432 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '3c52df71444a97030d460135fda56f61',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/39fe85f6dd94a340d384017ca3d93d90.vehicle',
    ),
    433 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'b4d7d783406522312b4d43db6d5ea825',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/8462af1afdfdd174cf3e1220b4d6da30.vehicle',
    ),
    434 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '45976f879103ea840c02c5e0399d636e',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/234c865fc61369c1485fb1bbb41007e9.vehicle',
    ),
    435 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '18821940e4eee17fbf09790dc5974173',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/aa13733cd50d614ad44c1bad614f09b7.vehicle',
    ),
    436 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '8bb14d114e335e5a4958ddc43d9cbddf',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/b136101f53991d2698cb7c9e032a5aa3.vehicle',
    ),
    437 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '6ae6659e87756c2c53c49891a6c0ecb4',
      'native_key' => 1,
      'filename' => 'modAccessPolicy/600831c20330b66bafe730e7537f5da1.vehicle',
    ),
    438 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'fbeae2fc52d82be20dcdd45167f281e2',
      'native_key' => 2,
      'filename' => 'modAccessPolicy/94714069c195bf7cbf909886a9d15d8e.vehicle',
    ),
    439 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '7beab6f7715e0536a762a2e7fea61fa6',
      'native_key' => 3,
      'filename' => 'modAccessPolicy/55d2d1cec1670f3484b7131342e79524.vehicle',
    ),
    440 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '8250ad77eb86b68313677cb6c4682a9f',
      'native_key' => 4,
      'filename' => 'modAccessPolicy/12e16d9b0071a0aa654437802ec8b4eb.vehicle',
    ),
    441 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'db250d8b925eb6f26c1083b3636de80d',
      'native_key' => 5,
      'filename' => 'modAccessPolicy/be9d1a64b66fede55e4c58a2cc109d08.vehicle',
    ),
    442 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '79770712e84ae7a3ba1cba79e8bd5c6c',
      'native_key' => 6,
      'filename' => 'modAccessPolicy/250c25b16f548a8e98eab2200912a802.vehicle',
    ),
    443 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'f595f737fa8cb378881b4a14cd089a3c',
      'native_key' => 7,
      'filename' => 'modAccessPolicy/08ae4c1c9f3c84bc1a5676dd66d60e38.vehicle',
    ),
    444 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '6fba86cad95319f15384562be1767406',
      'native_key' => 8,
      'filename' => 'modAccessPolicy/af0302e9c9f605abe5b89adf5c2688d1.vehicle',
    ),
    445 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '99d4254e91bbbe49310fdadac21d64c8',
      'native_key' => 9,
      'filename' => 'modAccessPolicy/0b54162c0447eeb6224bf8884450694c.vehicle',
    ),
    446 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '9ed863b7d78b54ea91126464a482e113',
      'native_key' => 10,
      'filename' => 'modAccessPolicy/f10e3c0440a1bcb28a106e93b6e326ad.vehicle',
    ),
    447 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '673e495680fbf2304ec9e62b4680be10',
      'native_key' => 11,
      'filename' => 'modAccessPolicy/0ec6318306fefc659b47630a096c5ca6.vehicle',
    ),
    448 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => '40d79529dd5157fe640a95665255494c',
      'native_key' => 'web',
      'filename' => 'modContext/0bbcdfc66f1618c1298ccd7dbcc72259.vehicle',
    ),
    449 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => '6feeeec4360716dd3c5b6a5e4b55c57f',
      'native_key' => 'mgr',
      'filename' => 'modContext/bc9913c61b19eeb211989b49202e3614.vehicle',
    ),
    450 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'ef47cba0f9d56f00a2200f55de7518b2',
      'native_key' => 'ef47cba0f9d56f00a2200f55de7518b2',
      'filename' => 'xPDOFileVehicle/235515cce960e1c34423c3483137bf15.vehicle',
    ),
    451 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '4f5f3e7156b594b6e072dbede647580f',
      'native_key' => '4f5f3e7156b594b6e072dbede647580f',
      'filename' => 'xPDOFileVehicle/340adaa02e1c349d1cf12b3957052074.vehicle',
    ),
    452 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '0bd2d6038630ff0c8d5f1e9053addd63',
      'native_key' => '0bd2d6038630ff0c8d5f1e9053addd63',
      'filename' => 'xPDOFileVehicle/5925cb565ad59a1f3f557fcdb06fb2ba.vehicle',
    ),
    453 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '444dc732590097dc0de0bdf0944c816f',
      'native_key' => '444dc732590097dc0de0bdf0944c816f',
      'filename' => 'xPDOFileVehicle/38debd032a2de5511423daf300fb14cc.vehicle',
    ),
  ),
);